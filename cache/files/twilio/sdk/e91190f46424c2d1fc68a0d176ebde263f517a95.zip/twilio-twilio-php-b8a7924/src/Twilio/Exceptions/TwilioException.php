<?php


namespace Twilio\Exceptions;


class TwilioException extends \Exception {

}